package Tree;

public class Dnode {

	int data ;
	
	Dnode left , right ;
	
	Dnode( int data)
	{
		this.data = data;
		this.left = null;
		this.right = null;
	}
}
